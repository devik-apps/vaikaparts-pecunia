

# PostRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**amount** | **String** |  |  [optional] |
|**currency** | **String** |  |  [optional] |
|**descriptionText** | **String** |  |  [optional] |
|**requestingOrganisationTransactionReference** | **String** |  |  [optional] |
|**requestDate** | **String** |  |  [optional] |
|**originalTransactionReference** | **String** |  |  [optional] |
|**debitParty** | [**List&lt;PostRequestDebitPartyInner&gt;**](PostRequestDebitPartyInner.md) |  |  [optional] |
|**creditParty** | [**List&lt;PostRequestDebitPartyInner&gt;**](PostRequestDebitPartyInner.md) |  |  [optional] |
|**metadata** | [**List&lt;PostRequestDebitPartyInner&gt;**](PostRequestDebitPartyInner.md) |  |  [optional] |



