# DefaultApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**rootPost**](DefaultApi.md#rootPost) | **POST** / |  |
| [**statusServerCorrelationIdGet**](DefaultApi.md#statusServerCorrelationIdGet) | **GET** /status/{serverCorrelationId} |  |
| [**transactionReferenceGet**](DefaultApi.md#transactionReferenceGet) | **GET** /{transactionReference} |  |


<a id="rootPost"></a>
# **rootPost**
> rootPost(version, xCorrelationID, cacheControl, postRequest, cellIdA, geoLocationA, cellIdB, geoLocationB, accept, acceptCharset, xCallbackURL)



Merchant pay

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.MVOLA_Merchant_Pay_API.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String version = "version_example"; // String | 
    String xCorrelationID = "xCorrelationID_example"; // String | 
    String cacheControl = "cacheControl_example"; // String | 
    PostRequest postRequest = new PostRequest(); // PostRequest | 
    String cellIdA = "cellIdA_example"; // String | 
    String geoLocationA = "geoLocationA_example"; // String | 
    String cellIdB = "cellIdB_example"; // String | 
    String geoLocationB = "geoLocationB_example"; // String | 
    String accept = "accept_example"; // String | 
    String acceptCharset = "acceptCharset_example"; // String | 
    String xCallbackURL = "xCallbackURL_example"; // String | 
    try {
      apiInstance.rootPost(version, xCorrelationID, cacheControl, postRequest, cellIdA, geoLocationA, cellIdB, geoLocationB, accept, acceptCharset, xCallbackURL);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#rootPost");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **version** | **String**|  | |
| **xCorrelationID** | **String**|  | |
| **cacheControl** | **String**|  | |
| **postRequest** | [**PostRequest**](PostRequest.md)|  | |
| **cellIdA** | **String**|  | [optional] |
| **geoLocationA** | **String**|  | [optional] |
| **cellIdB** | **String**|  | [optional] |
| **geoLocationB** | **String**|  | [optional] |
| **accept** | **String**|  | [optional] |
| **acceptCharset** | **String**|  | [optional] |
| **xCallbackURL** | **String**|  | [optional] |

### Return type

null (empty response body)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | ok |  -  |
| **202** | pending |  -  |

<a id="statusServerCorrelationIdGet"></a>
# **statusServerCorrelationIdGet**
> statusServerCorrelationIdGet(serverCorrelationId, version, xCorrelationID, userAccountIdentifier, partnerName, cacheControl, cellIdA, geoLocationA, accept, acceptCharset)



Transaction status

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.MVOLA_Merchant_Pay_API.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String serverCorrelationId = "serverCorrelationId_example"; // String | 
    String version = "version_example"; // String | 
    String xCorrelationID = "xCorrelationID_example"; // String | 
    String userAccountIdentifier = "userAccountIdentifier_example"; // String | 
    String partnerName = "partnerName_example"; // String | 
    String cacheControl = "cacheControl_example"; // String | 
    String cellIdA = "cellIdA_example"; // String | 
    String geoLocationA = "geoLocationA_example"; // String | 
    String accept = "accept_example"; // String | 
    String acceptCharset = "acceptCharset_example"; // String | 
    try {
      apiInstance.statusServerCorrelationIdGet(serverCorrelationId, version, xCorrelationID, userAccountIdentifier, partnerName, cacheControl, cellIdA, geoLocationA, accept, acceptCharset);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#statusServerCorrelationIdGet");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **serverCorrelationId** | **String**|  | |
| **version** | **String**|  | |
| **xCorrelationID** | **String**|  | |
| **userAccountIdentifier** | **String**|  | |
| **partnerName** | **String**|  | |
| **cacheControl** | **String**|  | |
| **cellIdA** | **String**|  | [optional] |
| **geoLocationA** | **String**|  | [optional] |
| **accept** | **String**|  | [optional] |
| **acceptCharset** | **String**|  | [optional] |

### Return type

null (empty response body)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | ok |  -  |

<a id="transactionReferenceGet"></a>
# **transactionReferenceGet**
> transactionReferenceGet(transactionReference, version, xCorrelationID, userAccountIdentifier, cacheControl, cellIdA, geoLocationA, accept, acceptCharset)



Transaction details

### Example
```java
// Import classes:
import org.wso2.client.api.ApiClient;
import org.wso2.client.api.ApiException;
import org.wso2.client.api.Configuration;
import org.wso2.client.api.auth.*;
import org.wso2.client.api.models.*;
import org.wso2.client.api.MVOLA_Merchant_Pay_API.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");
    
    // Configure OAuth2 access token for authorization: default
    OAuth default = (OAuth) defaultClient.getAuthentication("default");
    default.setAccessToken("YOUR ACCESS TOKEN");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String transactionReference = "transactionReference_example"; // String | 
    String version = "version_example"; // String | 
    String xCorrelationID = "xCorrelationID_example"; // String | 
    String userAccountIdentifier = "userAccountIdentifier_example"; // String | 
    String cacheControl = "cacheControl_example"; // String | 
    String cellIdA = "cellIdA_example"; // String | 
    String geoLocationA = "geoLocationA_example"; // String | 
    String accept = "accept_example"; // String | 
    String acceptCharset = "acceptCharset_example"; // String | 
    try {
      apiInstance.transactionReferenceGet(transactionReference, version, xCorrelationID, userAccountIdentifier, cacheControl, cellIdA, geoLocationA, accept, acceptCharset);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#transactionReferenceGet");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **transactionReference** | **String**|  | |
| **version** | **String**|  | |
| **xCorrelationID** | **String**|  | |
| **userAccountIdentifier** | **String**|  | |
| **cacheControl** | **String**|  | |
| **cellIdA** | **String**|  | [optional] |
| **geoLocationA** | **String**|  | [optional] |
| **accept** | **String**|  | [optional] |
| **acceptCharset** | **String**|  | [optional] |

### Return type

null (empty response body)

### Authorization

[default](../README.md#default)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | ok |  -  |

